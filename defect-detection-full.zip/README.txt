DEFECT DETECTION - QUICK START (Windows)

1. Extract this folder anywhere on your computer.
2. Install Python 3.10 or newer if it is not already installed.
3. Double-click launch_demo.bat.
4. When it finishes, open the results folder. Images ending in _overlay.png
   show detected areas in red.

To inspect your own images:
1. Put defect-free reference photos in data\normal.
2. Put photos to inspect in data\inspect.
3. Double-click run_on_my_images.bat.

Use the same camera, lighting, framing, and part alignment for all photos.
The detector is a reference-based starter and should be tuned with real samples
before production use.

Command-line usage (run in this folder):
  python -m pip install -r requirements.txt
  python defect_detection.py train data\normal
  python defect_detection.py detect data\inspect

Full documentation: see README.md.
