@echo off
cd /d "%~dp0"
echo Installing required packages...
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
echo.
echo Creating example images...
python defect_detection.py demo --output demo_data
if errorlevel 1 goto failed
echo.
echo Training on good example images...
python defect_detection.py train demo_data\normal --model model.npz
if errorlevel 1 goto failed
echo.
echo Inspecting sample images...
python defect_detection.py detect demo_data\inspect --model model.npz --output results
if errorlevel 1 goto failed
echo.
echo Done. Open the results folder and view files ending in _overlay.png.
pause
exit /b 0
:failed
echo.
echo Something went wrong. Make sure Python 3.10 or newer is installed and available as "python".
pause
exit /b 1
