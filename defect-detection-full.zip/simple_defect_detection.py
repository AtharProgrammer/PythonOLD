"""A tiny defect-detection demo using the included sample images.

Run from this folder:
    python simple_defect_detection.py

Idea: compare a known-good image with an image that may have a defect. Large
pixel differences are highlighted in red. This is a learning demo; it expects
the two images to show the part in the same position and lighting.
"""
from pathlib import Path

import cv2


HERE = Path(__file__).resolve().parent
GOOD_IMAGE = HERE / "demo_data" / "normal" / "normal_00.png"
IMAGE_TO_CHECK = HERE / "demo_data" / "inspect" / "part_00.png"
OUTPUT_IMAGE = HERE / "simple_result.png"


def main():
    # 1. Read both images as grayscale (one brightness value per pixel).
    good = cv2.imread(str(GOOD_IMAGE), cv2.IMREAD_GRAYSCALE)
    check = cv2.imread(str(IMAGE_TO_CHECK), cv2.IMREAD_GRAYSCALE)
    if good is None or check is None:
        raise FileNotFoundError(
            "Sample images are missing. Run this script from the complete "
            "project folder, which includes demo_data."
        )

    # 2. Make their sizes match so corresponding pixels can be compared.
    check = cv2.resize(check, (good.shape[1], good.shape[0]))

    # 3. Find how different each pixel is. Identical pixels have difference 0.
    difference = cv2.absdiff(good, check)

    # 4. Keep only large differences. Increase 30 to ignore more small changes;
    #    decrease it to make the demo more sensitive.
    _, mask = cv2.threshold(difference, 30, 255, cv2.THRESH_BINARY)

    # 5. Put the image being checked in color and paint detected pixels red.
    result = cv2.cvtColor(check, cv2.COLOR_GRAY2BGR)
    result[mask > 0] = (0, 0, 255)  # OpenCV uses BGR color order: blue, green, red.

    # 6. Save the marked result so it is easy to open from File Explorer.
    cv2.imwrite(str(OUTPUT_IMAGE), result)
    print(f"Pixels flagged as different: {cv2.countNonZero(mask)}")
    print(f"Result saved to: {OUTPUT_IMAGE}")


if __name__ == "__main__":
    main()
