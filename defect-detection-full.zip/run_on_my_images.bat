@echo off
cd /d "%~dp0"
if not exist data\normal mkdir data\normal
if not exist data\inspect mkdir data\inspect
if not exist data\normal\* (
  echo Add at least three defect-free photos to data\normal, then run this again.
  pause
  exit /b 1
)
if not exist data\inspect\* (
  echo Add photos to inspect to data\inspect, then run this again.
  pause
  exit /b 1
)
python -m pip install -r requirements.txt
if errorlevel 1 goto failed
python defect_detection.py train data\normal --model model.npz
if errorlevel 1 goto failed
python defect_detection.py detect data\inspect --model model.npz --output results
if errorlevel 1 goto failed
echo Done. Open the results folder and view files ending in _overlay.png.
pause
exit /b 0
:failed
echo Something went wrong. Make sure Python 3.10 or newer is installed and available as "python".
pause
exit /b 1
