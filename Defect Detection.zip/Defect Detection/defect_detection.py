"""Reference-based industrial surface defect detector.

Train on a directory of defect-free images, then score new images against the
learned per-pixel normal appearance. Images should use a consistent camera,
lighting, orientation, and framing. See README.md for limitations and usage.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff"}
MODEL_VERSION = 1


def image_paths(path: Path) -> list[Path]:
    if path.is_file():
        return [path] if path.suffix.lower() in IMAGE_EXTENSIONS else []
    if path.is_dir():
        return sorted(p for p in path.rglob("*") if p.suffix.lower() in IMAGE_EXTENSIONS)
    return []


def read_image(path: Path, size: tuple[int, int] | None = None) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f"Could not read image: {path}")
    if size and (image.shape[1], image.shape[0]) != size:
        image = cv2.resize(image, size, interpolation=cv2.INTER_AREA if image.shape[1] > size[0] else cv2.INTER_LINEAR)
    return image


def features(image: np.ndarray) -> np.ndarray:
    """Build illumination-tolerant grayscale/edge feature planes."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY).astype(np.float32) / 255.0
    # Per-image centering removes modest global brightness changes. Keep contrast
    # in the feature so local texture and shape changes remain detectable.
    gray = np.clip((gray - float(np.median(gray))) / max(float(np.std(gray)), 0.04), -3.0, 3.0)
    gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3) / 8.0
    gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3) / 8.0
    lap = cv2.Laplacian(gray, cv2.CV_32F, ksize=3) / 4.0
    return np.stack((gray, gx, gy, lap), axis=-1)


def train(normal_dir: Path, model_path: Path, max_images: int = 500) -> dict:
    paths = image_paths(normal_dir)[:max_images]
    if len(paths) < 3:
        raise ValueError(f"Training needs at least 3 normal images; found {len(paths)} in {normal_dir}")
    first = read_image(paths[0])
    size = (first.shape[1], first.shape[0])
    stack = np.stack([features(read_image(p, size)) for p in paths], axis=0)
    mean = np.mean(stack, axis=0).astype(np.float32)
    # Standard deviation is robustly floored to prevent tiny training variance
    # from making harmless sensor noise look anomalous.
    std = np.maximum(np.std(stack, axis=0), 0.06).astype(np.float32)
    z = np.abs((stack - mean) / std)
    calibration = float(np.quantile(z, 0.995))
    threshold = float(np.clip(max(3.5, calibration * 1.25), 3.5, 8.0))
    model_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(model_path, version=MODEL_VERSION, mean=mean, std=std,
                        width=size[0], height=size[1], threshold=threshold,
                        training_images=len(paths))
    return {"model": str(model_path), "training_images": len(paths),
            "image_size": f"{size[0]}x{size[1]}", "threshold": round(threshold, 3)}


def load_model(path: Path) -> dict:
    if not path.is_file():
        raise ValueError(f"Model not found: {path}. Run the train command first.")
    with np.load(path, allow_pickle=False) as data:
        if int(data["version"]) != MODEL_VERSION:
            raise ValueError("Unsupported model version. Retrain with this version of the project.")
        return {k: data[k].copy() for k in data.files}


def detect(image: np.ndarray, model: dict, threshold: float | None = None,
           min_area: int = 20) -> tuple[np.ndarray, np.ndarray, dict]:
    size = (int(model["width"]), int(model["height"]))
    if (image.shape[1], image.shape[0]) != size:
        image = cv2.resize(image, size, interpolation=cv2.INTER_AREA if image.shape[1] > size[0] else cv2.INTER_LINEAR)
    scores = np.max(np.abs((features(image) - model["mean"]) / model["std"]), axis=-1)
    # Smooth isolated sensor noise while preserving small, connected flaws.
    scores = cv2.GaussianBlur(scores.astype(np.float32), (3, 3), 0.6)
    cutoff = float(threshold if threshold is not None else model["threshold"])
    mask = (scores >= cutoff).astype(np.uint8) * 255
    count, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    clean = np.zeros_like(mask)
    areas = []
    for label in range(1, count):
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area >= min_area:
            clean[labels == label] = 255
            areas.append(area)
    score = float(np.percentile(scores, 99.5))
    info = {"defect_detected": bool(areas), "score_99_5": round(score, 3),
            "threshold": round(cutoff, 3), "defect_regions": len(areas),
            "defect_pixels": int(np.count_nonzero(clean)),
            "largest_region_pixels": max(areas, default=0)}
    return scores, clean, info


def save_result(image: np.ndarray, scores: np.ndarray, mask: np.ndarray,
                output_dir: Path, stem: str, info: dict) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    heat = cv2.applyColorMap(np.uint8(np.clip(scores / max(info["threshold"] * 2, 1) * 255, 0, 255)), cv2.COLORMAP_JET)
    overlay = image.copy()
    red = np.zeros_like(image)
    red[:, :, 2] = 255
    marked = mask > 0
    overlay[marked] = cv2.addWeighted(image[marked], 0.35, red[marked], 0.65, 0)
    cv2.imwrite(str(output_dir / f"{stem}_heatmap.png"), heat)
    cv2.imwrite(str(output_dir / f"{stem}_mask.png"), mask)
    cv2.imwrite(str(output_dir / f"{stem}_overlay.png"), overlay)
    (output_dir / f"{stem}_result.json").write_text(json.dumps(info, indent=2), encoding="utf-8")


def command_train(args: argparse.Namespace) -> int:
    result = train(args.normal_dir, args.model, args.max_images)
    print(json.dumps(result, indent=2))
    return 0


def command_detect(args: argparse.Namespace) -> int:
    model = load_model(args.model)
    paths = image_paths(args.input)
    if not paths:
        raise ValueError(f"No supported images found at {args.input}")
    results = []
    for path in paths:
        image = read_image(path)
        scores, mask, info = detect(image, model, args.threshold, args.min_area)
        resized = cv2.resize(image, (int(model["width"]), int(model["height"])))
        save_result(resized, scores, mask, args.output, path.stem, info)
        results.append({"image": str(path), **info})
    print(json.dumps(results, indent=2))
    return 0


def make_demo(args: argparse.Namespace) -> int:
    """Create repeatable sample images to exercise the full workflow."""
    rng = np.random.default_rng(args.seed)
    root = args.output
    normal = root / "normal"
    defective = root / "inspect"
    normal.mkdir(parents=True, exist_ok=True)
    defective.mkdir(parents=True, exist_ok=True)
    h, w = 256, 384
    yy, xx = np.mgrid[0:h, 0:w]
    base = 150 + 12 * np.sin(xx / 45) + 7 * np.cos(yy / 31)
    for i in range(16):
        noise = rng.normal(0, 2.0, (h, w))
        gray = np.uint8(np.clip(base + noise + rng.normal(0, 1), 0, 255))
        cv2.imwrite(str(normal / f"normal_{i:02d}.png"), cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR))
    for i in range(3):
        noise = rng.normal(0, 2.0, (h, w))
        gray = np.uint8(np.clip(base + noise, 0, 255))
        # A dark scratch and a small pit simulate visible surface flaws.
        cv2.line(gray, (105 + i * 5, 70), (245, 125 + i * 8), 48, 4)
        cv2.circle(gray, (285, 180), 8 + i, 65, -1)
        cv2.imwrite(str(defective / f"part_{i:02d}.png"), cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR))
    print(f"Created demo dataset at {root}")
    print(f"Normal training images: {normal}")
    print(f"Images to inspect: {defective}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Train and run a reference-based visual surface defect detector.")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("train", help="Train on defect-free reference images")
    p.add_argument("normal_dir", type=Path)
    p.add_argument("--model", type=Path, default=Path("model.npz"))
    p.add_argument("--max-images", type=int, default=500)
    p.set_defaults(func=command_train)
    p = sub.add_parser("detect", help="Inspect one image or a folder of images")
    p.add_argument("input", type=Path)
    p.add_argument("--model", type=Path, default=Path("model.npz"))
    p.add_argument("--output", type=Path, default=Path("results"))
    p.add_argument("--threshold", type=float, default=None, help="Override learned anomaly threshold")
    p.add_argument("--min-area", type=int, default=20, help="Ignore connected regions smaller than this many pixels")
    p.set_defaults(func=command_detect)
    p = sub.add_parser("demo", help="Generate a small synthetic dataset for a first run")
    p.add_argument("--output", type=Path, default=Path("demo_data"))
    p.add_argument("--seed", type=int, default=7)
    p.set_defaults(func=make_demo)
    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    try:
        return args.func(args)
    except (ValueError, OSError, cv2.error) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
