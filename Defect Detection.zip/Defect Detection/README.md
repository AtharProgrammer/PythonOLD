# Defect Detection

A complete, local Python example for training a visual surface anomaly detector on known-good images and flagging unusual regions in new images. It creates a heatmap, binary defect mask, red overlay, and JSON summary for every image inspected.

## Quick start

Requires Python 3.10 or newer. From this folder:

```powershell
python -m pip install -r requirements.txt
python defect_detection.py demo
python defect_detection.py train demo_data/normal
python defect_detection.py detect demo_data/inspect
```

Results are written to `results/`. Open `*_overlay.png` to see flagged pixels, `*_heatmap.png` to see anomaly strength, and `*_result.json` for the decision and region counts.

## Use your own images

1. Put at least three defect-free images into a folder such as `data/normal/`.
2. Put inspection images into `data/inspect/` (subfolders are scanned too).
3. Keep camera position, focus, lighting, part orientation, and image framing consistent. Images can have different resolutions; they are resized to the training resolution.
4. Run:

```powershell
python defect_detection.py train data/normal --model model.npz
python defect_detection.py detect data/inspect --model model.npz --output results
```

Optional detection controls: `--threshold 4.0` changes the anomaly cutoff; `--min-area 20` changes the minimum connected defect size in pixels. Lower thresholds catch subtler differences but may raise more false alarms.

## What it does

Training records the normal per-pixel distribution of grayscale appearance, edges, and fine texture from the good reference images. Detection compares each new image with that learned appearance, groups neighboring anomalous pixels into regions, and saves visual and machine-readable output. This is a lightweight, explainable baseline and does not require a GPU or downloaded weights.

## Important limits

This reference-based method works best with a fixed inspection setup and repeatable part alignment. It is not a general-purpose classifier and does not identify defect types. Large shifts in part position, rotation, focus, reflections, or lighting can be flagged as defects; use image registration or a purpose-built segmentation model for those production conditions. Tune the threshold and minimum region size on representative good and defective samples before relying on it for quality decisions.
